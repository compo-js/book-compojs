<?php
  // создать класс Товаров
  class Product {}

  // создать объект товара
  $product = new Product();

  // добавить название товара
  $product->title = 'Красный';

  // добавить описание товара
  $product->descript = 'Этот цвет символизирует радость, красоту, любовь и полноту жизни, а с другой стороны - вражду, месть, войну, связывается с агрессивностью и плотскими желаниями.';
  
  // добавить путь к изображению товара
  $product->src = 'img/red.jpg';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Товар</title>
</head>
<body>
  <!-- тег монтирования компонента 'c-product' -->
  <c-product>
    <!-- передать название товара в компонент, через именованный слот 'title' -->
    <h1 slot="title"><?php echo($product->title); ?></h1>

    <!-- передать описание товара в компонент, через именованный слот 'descript' -->
    <p slot="descript"><?php echo($product->descript); ?></p>
    
    <!-- передать изображение товара в компонент, через именованный слот 'img' -->
    <img slot="img" src="<?php echo($product->src); ?>" alt="">
  </c-product>

  <!-- тег подключения компонента 'c-product' -->
  <template src="product.htm"></template>
  
  <!-- подключить CompoJS -->
  <script src="compo.min.js"></script>
</body>
</html>